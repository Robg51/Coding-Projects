/*
Author: Robby Gonzalez
The purpose of this class is to create constructors and
their internal variables to be used in TreasureMap.java and
AssignmentOneB.java
 */
public class Spot {
    boolean hasTreasure;
    boolean isSearched;

    /**
     * A constructor for a spot on the Treasure Map
     */
    public Spot(){
        hasTreasure = false;
        isSearched = false;
    }

    /**
     * A constructor for a spot on the Treasure Map
     * that contains treasure
     * @param treasure a boolean variable for treasure
     */
    public Spot(boolean treasure){
        treasure = hasTreasure;
        isSearched = false;
    }

    /**
     * A getter to find the spot where
     * the treasure is.
     */
    public boolean getHasTreasure(){
        return hasTreasure;
    }

    /**
     * A getter constructor that will be used
     * to determine if a spot has been searched yet.
     */
    public boolean getIsSearched(){
        return isSearched;
    }

    /**
     * A setter constructor variable to designate
     * if a spot has been searched before.
     */
    public void setIsSearched(){
        isSearched = true;
    }

    /**
     * A toString method to properly show the
     * contents of the Treasure Map
     */
    public String toString(){
        if(isSearched == true && hasTreasure == false){
            return "Y";
        }
        else if(isSearched == true && hasTreasure == true){
            return "T";
        }
        else{
            return "P";
        }
    }
}
