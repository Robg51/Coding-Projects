import java.util.LinkedList;

public class LinearProbingHT<Key, Value> implements SymbolTable<Key, Value> {
    private int size;
    private Pair<Key, Value> array1[];
    private LinkedList<Key> keyList = new LinkedList<>();
    protected int numElements = 0;

    protected class Pair<K,V> {
        K key;
        V value;
        Pair(K key, V value) {
            this.key = key;
            this.value = value;
        }
    }

    LinearProbingHT(){
        size = 997;
        array1 = (Pair<Key, Value>[]) new Pair[size];
    }

    @Override
    public void put(Key o, Value val) {
        int start = hash(o);
        for (int i = 0; i < size; i++) {
            // do something with the array
            Pair<Key, Value> currentPos = array1[(start + i) % size];
            if(currentPos == null){
                Pair<Key, Value> newPair = new Pair<>(o,val);
                array1[(start + i) % size] = newPair;
            }
            else if(currentPos.key == o){
                currentPos.value = val;
            }
            numElements++;
        }
    }

    @Override
    public Value get(Key o) {
        Pair<Key, Value> pair = getPair(o);
        if(pair != null){
            return pair.value;
        }
        else{
            return null;
        }
    }

    @Override
    public void delete(Key o) {
        int start = hash(o);
        for (int i = 0; i < size; i++) {
            // do something with the array
            Pair<Key, Value> currentPos = array1[(start + i) % size];
            if(currentPos != null && currentPos.key == o){
                keyList.remove(o);
                array1[(start + i) % size] = null;
                numElements--;
            }
        }
    }

    //helper method
    private Pair<Key, Value> getPair(Key o){
        int start = hash(o);
        for (int i = 0; i < size; i++) {
            // do something with the array
            Pair<Key, Value> currentPos = array1[(start + i) % size];
            if(currentPos == null){
                return null;
            }
            else if(currentPos.key == o){
                return currentPos;
            }
        }
        return null;
    }

    @Override
    public boolean contains(Key o) {
       if(getPair(o) != null) {
           return true;
       }
       else{
           return false;
       }
    }

    @Override
    public boolean isEmpty() {
        return numElements != 0;
    }

    @Override
    public int size() {
        return numElements;
    }

    @Override
    public Iterable<Key> keys() {
        return (Iterable<Key>) keyList.clone();
    }
    private int hash(Key key){
        return (key.hashCode() & 0x7fffffff ) % 997;
    }


}
