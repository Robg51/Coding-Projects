public class QuadProbingHT<Key, Value> extends LinearProbingHT<Key, Value> implements SymbolTable<Key,Value> {

    private Pair<Key, Value> array2[];

    public QuadProbingHT(){
        super();
    }
    //I used the function that didnt contain any collisions in LinearProbeHT
    public void put(Key key, Value val){
        int start = newHash(key, numElements);


        for(int i = 0; i < 997; i++){

        }


    }

    private int newHash(Key key, int i){
        return ((key.hashCode() & 0x7fffffff) + i) % 997;
    }
}
