import java.util.LinkedList;

public class IntuitiveTopological implements TopologicalSort {
    BetterDiGraph diGraph;
    LinkedList list = new LinkedList<>();
    public IntuitiveTopological(BetterDiGraph graph){
        diGraph = graph;
    }

    @Override
    public Iterable<Integer> order() {
        int counter = 0;
        if(diGraph.isEmpty()){
             return list;
         }
         else{
            boolean found = false;
            for (Integer vertex : diGraph.vertices()) {
                if (diGraph.getIndegree(vertex) == 0) {
                    found = true;
                    counter = vertex;
                    list.add(counter);
                    diGraph.removeVertex(counter);
                    break;
                }
            }
            if(found == false){
                return null;
            }


             order();
             return list;
        }
    }

    @Override
    public boolean isDAG() {
        return order() == null;
    }
}
