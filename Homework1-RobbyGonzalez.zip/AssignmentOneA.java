//HEADER HERE
/*
Author: Robby Gonzalez, Dr. Gonzalez-Sanchez
This program is to show my basic knowledge of the lexical. syntactical, and semantic use of java
Specifically with primitive data types, searching, and recursion.
 */
//HEADER END
public class AssignmentOneA {
    public static void main(String[] args) {
        char [] a = {'f', 'D', 'G', '5', '!', 'b', '1', 'q', 'S', 'T'};
        char [] b = {'j', '3', 'd', 'c', '3', 'c', 'd', '3', 'j'};
        int [] c = {7, 1, 6, 3, 5};
        int [] d = { 12, 5, 15, 1, 3};
        // testing initializeArray
        printArray(a); // print: f D G 5 ! b 1 q S T
        toggleArray(a);
        printArray(a); // print: F d g 5 ! B 1 Q s t
        insertionSort(c);
        insertionSort(d);
        // testing insertionSort
        System.out.println(printArray(c));// print: {1, 3, 5, 6, 7}
        System.out.println(printArray(d)); // print: {1, 3, 5, 12, 15}
        // testing fibonacci
        System.out.println(fibonacci (6)); //print: 8
        System.out.println(fibonacci (c[3])); //print: 8
        System.out.println(fibonacci (d[1])); //print: 2
    }

    //CODE HERE
    /**
     * Receives an array of chars then prints the array
     * @param array1 an array of characters
     */
    public static void printArray(char[] array1){
        for(int i = 0; i < array1.length; i++){
            System.out.print(array1[i] + " ");
        }
        System.out.println();
    }

    /**
     * Receives an array of integers then prints the array
     * @param array2 an array of ingtegers
     */
    public static String printArray(int[] array2) {
        String output = "";
        for (int i = 0; i < array2.length; i++) {
            output += (array2[i] + " ");
        }
        System.out.println();
        return output;
    }

    /**
     * Receives an array of chars then switches each letters casing
     * in the array. it then prints the array
     * @param array3 an array of characters
     */
    public static void toggleArray(char[] array3){
        for(int i = 0; i < array3.length; i++){
            if (Character.isUpperCase(array3[i])){
                System.out.print(Character.toLowerCase(array3[i]) + " ");
            }
            else{
                System.out.print(Character.toUpperCase(array3[i]) + " ");
            }

        }
        System.out.println();
    }

    /**
     * Receives an array of integers, then sorts the
     * array in ascending order using Insertion Sort.
     * @param array4 an array of integers
     */
    public static void insertionSort(int[] array4){
        int arrLength = array4.length;
        for(int i = 1; i < arrLength; i++){
            int key = array4[i];
            int j = i - 1;

            while(j >= 0 && array4[j] > key){
                array4[j + 1] = array4[j];
                j = j - 1;
            }
            array4[j + 1] = key;
        }
    }

    /**
     * Receives an integer number and calculates
     * the nth fibonacci of a user given number
     * @param n an integer number
     */
    public static int fibonacci(int n){
        if((n == 0 || n == 1)) {
            return n;
        }
        else{
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }


    //END CODE HERE
}