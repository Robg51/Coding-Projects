import java.util.LinkedList;

public class TwoProbeChainHT<Key,Value> implements SymbolTable<Key, Value>{
    private int size;
    private LinkedList<Pair> array1[];
    private LinkedList<Pair> array2[];
    private LinkedList<Key> keyList = new LinkedList<>();
    protected int numElements = 0;

    private class Pair {
        Key key;
        Value value;
        Pair(Key key, Value value) {
            this.key = key;
            this.value = value;
        }
    }

    TwoProbeChainHT(){
        size = 997;
        array1 = (LinkedList<Pair>[]) new LinkedList[size];
        array2 = (LinkedList<Pair>[]) new LinkedList[size];
    }

    @Override
    public void put(Key o, Value val) {
        int a = hash1(o);
        int b = hash2(o);

        LinkedList<Pair> probeList = a <= b ? array1[a] : array2[b];
        if(probeList == null){
            LinkedList<Pair> list1 = new LinkedList<>();
            list1.add(new Pair(o,val));
            numElements++;
            keyList.add(o);
            if(a <= b){
                array1[a] = list1;
            }
            else{
                array2[b] = list1;
            }
        }
        else{
            probeList.add(new Pair(o,val));
            numElements++;
            keyList.add(o);
        }
    }

    @Override
    public Value get(Key o) {
       Pair pair = getPair(o);
       if(pair != null){
           return pair.value;
       }
       else{
           return null;
       }
    }


    @Override
    public void delete(Key o) {
        int a = hash1(o);
        int b = hash2(o);

        LinkedList<Pair> probeList = a <= b ? array1[a] : array2[b];
        if(probeList != null) {
            Pair matchingPair = null;
            for (Pair pair : probeList) {
                if (pair.key == o) {
                    matchingPair = pair;
                    break;
                }
            }
            if(matchingPair != null){
                probeList.remove(matchingPair);
                numElements--;
                keyList.remove(o);
            }
        }
    }

    //helper function
    private Pair getPair(Key o){
        int a = hash1(o);
        int b = hash2(o);

        LinkedList<Pair> probeList = a <= b ? array1[a] : array2[b];
        if(probeList == null) {
            return null;
        }
        for (Pair pair : probeList) {
            if(pair.key == o){
                return pair;
            }
        }
        return null;
    }
    @Override
    public boolean contains(Key o) {
        return getPair(o) != null;
    }

    @Override
    public boolean isEmpty() {
        return numElements != 0;
    }

    @Override
    public int size() {
        return numElements;
    }

    @Override
    public Iterable<Key> keys() {
       return (Iterable<Key>) keyList.clone();

    }

    private int hash1(Key key){
          return (key.hashCode() & 0x7fffffff ) % size;
    }

    private int hash2(Key key) {
        return (((key.hashCode() & 0x7fffffff ) % size) * 31) % size;
    }

}
