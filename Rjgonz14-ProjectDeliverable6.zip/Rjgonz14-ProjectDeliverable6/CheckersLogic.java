import java.util.*;
/**
 * This program is a basic implementation of Java
 * Console Text-Based Checkers.
 *
 * Completion time: 11 hrs
 *
 * @author Robby Gonzalez
 * @version 3/1/2022
 */

public class CheckersLogic extends CheckersTextConsole {

    /**
     * This method begins the game with player x to 
     * start the game, it first will scan and save 
     * the players input for their desired checker piece,
     * then it will scan and save the players input for the 
     * space that they would like to move to
     * */
    public void getNextMove()  {

        Scanner stdin = new Scanner(System.in);

        if (playerMove == 'x')
            System.out.println("It is your turn, x.");
        else
            System.out.println("It is your turn, o.");

        boolean moved = false;
        while (!moved) {
            System.out.println("Enter from the square you would like to move from.");
            System.out.println("as a letter followed by a number. (e.g. 'a1,c7,etc.')");
            String firstInput = (stdin.nextLine());
            int moveFrom = translatePos(firstInput);

            System.out.print("Enter from the square you would like to move to, ");
            System.out.println("using the same convention.");
            String secondInput = stdin.nextLine();
            int moveTo = translatePos(secondInput);

            if (validMove(moveFrom, moveTo)) {
                executeMove(moveFrom, moveTo);
                moved = true;
            } else
                System.out.println("That was an invalid move, try again.");
        }

        if (playerMove == 'x')
            playerMove = 'o';
        else
            playerMove = 'x';
    }

    /**
     * This method checks to see if the move the player wants 
     * to make is valid and acceptable to make. It first takes 
     * the translated user input for the checker and determines 
     * the index of the selected checker. it then takes the translated 
     * user input for the new checker space and determines its index. 
     * It then takes the previously determined indices and runs them 
     * through a series of checks to make sure that the desired move 
     * is applicable. If it is,return true, if not, return false.
     * @param moveFrom the original checker index
     *
     * @param moveTo the new index for the checker to move to
     * @return boolean ValidMove
     */
    public boolean validMove(int moveFrom, int moveTo) {

        int xFrom = moveFrom / 10 - 1;
        int yFrom = moveFrom % 10 - 1;
        int xTo = moveTo / 10 - 1;
        int yTo = moveTo % 10 - 1;

        if (xFrom < 0 || xFrom > 7 || yFrom < 0 || yFrom > 7 ||
                xTo < 0 || xTo > 7 || yTo < 0 || yTo > 7)
            return false;

        else if (board[xFrom][yFrom] == playerMove && board[xTo][yTo] == '_') {

            if (Math.abs(xFrom - xTo) == 1) {
                if ((playerMove == 'x') && (yTo - yFrom == 1))
                    return true;
                else if ((playerMove == 'o') && (yTo - yFrom == -1))
                    return true;
            }

            else if (Math.abs(xFrom - xTo) == 2) {
                if (playerMove == 'x' && (yTo - yFrom == 2) &&
                        board[(xFrom + xTo) / 2][(yFrom + yTo) / 2] == 'o')
                    return true;
                else if (playerMove == 'o' && (yTo - yFrom == -2) &&
                        board[(xFrom + xTo) / 2][(yFrom + yTo) / 2] == 'x')
                    return true;
            }
        }
        return false;
    }

    /**
     * this method will execute the player desired move 
     * after it has passed the check from the earlier method.
     * it removes the checker from the first index given (moveFrom)
     * and replaces it at the second given user index (moveTo). 
     * This method will also decrement X and O checkers
     * as needed to account for checker skips.
     *
     * @param moveFrom original checker index
     * @param moveTo selected new checker index
     */
    public void executeMove(int moveFrom, int moveTo) {
        int xFrom = moveFrom / 10 - 1;
        int yFrom = moveFrom % 10 - 1;
        int xTo = moveTo / 10 - 1;
        int yTo = moveTo % 10 - 1;


        board[xFrom][yFrom] = '_';
        board[xTo][yTo] = playerMove;
        if (Math.abs(xTo - xFrom) == 2) {
            board[(xFrom + xTo) / 2][(yFrom + yTo) / 2] = '_';
            if (playerMove == 'x')
                Xcheckers--;
            else
                Ocheckers--;
        }

    }

    /**
     * sets the game as over when a player has 
     * no checkers left in their hand
     * @return game over status
     */
    public boolean gameOver() {
        return (Xcheckers == 0 || Ocheckers == 0);
    }

    /** Returns the winner of the game when one 
     * player is out of checkers
     * @return winner of game
     */
    public String winner() {
        if (Ocheckers == 0)
            return "o";
        else
            return "x";
    }

    /**
     * Takes the string representation of an index 
     * then translates and returns it as an int in
     * order for it to be read into other functions.
     * @param move The move to be translated.
     * @return The int array of the row and column.
     */
    public int translatePos(String move) {

        try {
            move = move.replace("a", "1");
            move = move.replace("b", "2");
            move = move.replace("c", "3");
            move = move.replace("d", "4");
            move = move.replace("e", "5");
            move = move.replace("f", "6");
            move = move.replace("g", "7");
            move = move.replace("h", "8");
        }
        catch(NoSuchElementException e){
            throw new NoSuchElementException();
        }
        return Integer.parseInt(move);
    }

    public static void main(String[] args) {

        CheckersLogic game = new CheckersLogic();
        game.printBoard();

        while (!game.gameOver()) {
            game.getNextMove();
            game.printBoard();
        }
        System.out.println("The winner is " + game.winner());
    }
}