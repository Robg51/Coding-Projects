package edu.ser222.m01_03;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * CompletedList represents an implementation of a list.
 *
 * @author Robby Gonzalez, Acuna
 * @version (version)
 */
public class CompletedList<T> implements ListADT<T>, Iterable<T> {

    // Three instance variables have been created, you must use/keep them. Feel free to add more.
    protected int count;
    protected int modChange;
    protected DoubleLinearNode<T> head, tail;

    public CompletedList() {
        count = 0;
    }

    /**
     * Removes and returns the first element from this collection.
     *
     * @return the first element from this collection
     * @throws NoSuchElementException if the collection is empty
     */
    public T removeFirst() {
        if(count <= 0){
            throw new NoSuchElementException("Cannot remove from an empty list!");
        }
        head = head.next; //replaces the front with the next node after the front
        count--;
        modChange++;
        if(count == 0){
            tail = null;
        }
        return head.data;
    }

    /**
     * Removes and returns the last element from this collection.
     *
     * @return the last element from this collection
     * @throws NoSuchElementException if the collection is empty
     */
    public T removeLast() throws NoSuchElementException {
        if(count <= 0){
            throw new NoSuchElementException("Cannot remove from an empty list!");
        }
        tail = tail.prev; //replaces the front with the next node after the front
        count--;
        modChange++;
        if(count == 0){
            head = null;
        }
        return tail.data;    }

    /**
     * Removes and returns the specified element from this collection.
     *
     * @param element the element to be removed from the collection
     * @throws NoSuchElementException if the target is not in the collection
     */
    public T remove(T element) {
        DoubleLinearNode<T> current;
        current = head;
        while(current != null){
            if(current.data == element){   //if the temporary value "current" == the current element
                current.prev.next = current.next;  // then
                current.next.prev = current.prev;
                count--;
                modChange++;
                return element;
            }
            current = current.next;
        }//end of list
        throw new NoSuchElementException();
    }

    /**
     * Returns, without removing, the first element in the collection.
     *
     * @return a reference to the first element in this collection
     * @throws NoSuchElementException if the collection is empty
     */
    public T first() {
        if(count == 0){
            throw new NoSuchElementException("This is an empty list!");
        }
        return head.data;
    }

    /**
     * Returns, without removing, the last element in the collection.
     *
     * @return a reference to the last element in this collection
     * @throws NoSuchElementException if the collection is empty
     */
    public T last() {
        if(count == 0){
            throw new NoSuchElementException("This is an empty list!");
        }
        return tail.data;
    }

    /**
     * Returns true if this collection contains the specified target element, false otherwise.
     *
     * @param target the target that is being sought in the collection
     * @return true if the collection contains this element
     */
    public boolean contains(T target) {
        DoubleLinearNode<T> currentNode;
        currentNode = head;
        while(currentNode != null){
            if(currentNode.data == target){
                return true;
            }
        }

        return false;
    }

    /**
     * Returns true if this collection is empty and false otherwise.
     *
     * @return true if this collection empty
     */
    public boolean isEmpty() {
        if(count == 0){
            return true;
        }
        return false;
    }

    /**
     * Returns the number of elements in this collection.
     *
     * @return the number of elements in this collection
     */
    public int size() {
        return count;
    }

    /**
     * Returns an iterator for the elements in this collection.
     *
     * @return an iterator over the elements in this collection
     */

    public Iterator<T> iterator() {
      return new ListIterator();
    }

    /**
     * Returns a string representation of this collection.
     *
     * @return a string representation of this collection
     */
    public String toString(){
        String result = "";
        if (isEmpty()) {
            return "empty";
        }
        else {
            result += head.data.toString();
            DoubleLinearNode<T> current = head.next();
            while (current != null) {
                result += " " + current.data.toString();
                current = current.next();
            }
            return result;
        }
    }

    private class ListIterator implements Iterator<T> {
        private DoubleLinearNode<T> currentNode;
        private final int startModCount;

        private ListIterator(){
            currentNode = head;
            startModCount = modChange;
        }

        public T next(){
            if(startModCount != modChange){
                throw new ConcurrentModificationException();
            }
            if(currentNode == null){
                throw new NoSuchElementException();
            }
            T data = currentNode.data;
            currentNode = currentNode.next;
            return data;
        }

        @Override
        public boolean hasNext() {
            if(currentNode == null){
                return false;
            }
            return true;
        }
    }
}

class DoubleLinearNode<Item> {

    protected DoubleLinearNode<Item> next;
    protected DoubleLinearNode<Item> prev;
    protected Item data;

    public DoubleLinearNode() {
        this(null);
    }

    public DoubleLinearNode(Item elem){
        data = elem;
        next = null;
        prev = null;
    }

    public DoubleLinearNode<Item> next() {
        return next;
    }

    public void setNext(DoubleLinearNode<Item> node) {
        next = node;
    }

    public DoubleLinearNode<Item> prev() {
        return prev;
    }

    public void setPrev(DoubleLinearNode<Item> node) {
        prev = node;
    }


}
