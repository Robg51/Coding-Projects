package com.example.rockpaperscissors.RPSServer;
import java.io.*;
import java.net.*;
import java.util.Date;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

import static com.example.rockpaperscissors.RPSServer.RPSConstants.*;

public class RPSClient extends Application {

    private int choice;
    private boolean amP1;
    private int roundCount = 0;
    private int p1Wins = 0;
    private int p2Wins = 0;

    // Create and initialize a title label
    private Label lblTitle = new Label();

    // Create and initialize a status label
    private Label lblStatus = new Label();

    // Input and output streams from/to server
    private DataInputStream fromServer;
    private DataOutputStream toServer;

    // Continue to play?
    private boolean continueToPlay = true;

    // Wait for the player to mark a cell
    private boolean waiting = true;

    // Host name or ip
    private String host = "localhost";

    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {

        Button rock = new Button("Rock");
        rock.setOnMouseClicked(e -> {
            choice = ROCK;
            waiting = false;
        });

        Button paper = new Button("Paper");
        paper.setOnMouseClicked(e -> {
            choice = PAPER;
            waiting = false;
        });

        Button scissors = new Button("Scissors");
        scissors.setOnMouseClicked(e -> {
            choice = SCISSORS;
            waiting = false;
        });

        BorderPane borderPane = new BorderPane();
        borderPane.setTop(lblTitle);
        VBox vbox = new VBox();
        vbox.setPadding(new Insets(10));
        vbox.getChildren().addAll(rock,paper,scissors);
        borderPane.setCenter(vbox);
        borderPane.setBottom(lblStatus);


        // Create a scene and place it in the stage
        Scene scene = new Scene(borderPane, 320, 350);
        primaryStage.setTitle("RPSClient"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage

        // Connect to the server
        connectToServer();
    }

    private void connectToServer() {
        try {
            // Create a socket to connect to the server
            Socket socket = new Socket(host, 8000);

            // Create an input stream to receive data from the server
            fromServer = new DataInputStream(socket.getInputStream());

            // Create an output stream to send data to the server
            toServer = new DataOutputStream(socket.getOutputStream());
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }

        // Control the game on a separate thread
        new Thread(() -> {
            try {
                // Get notification from the server
                int player = fromServer.readInt();

                // Am I player 1 or 2?
                if (player == PLAYER1) {
                    amP1 = true;
                    Platform.runLater(() -> {
                        lblTitle.setText("Player 1");
                        lblStatus.setText("Waiting for player 2 to join");
                    });

                    // Receive startup notification from the server
                    fromServer.readInt(); // Whatever read is ignored

                    // The other player has joined
                    Platform.runLater(() ->
                            lblStatus.setText("Player 2 has joined."));

                }
                else if (player == PLAYER2) {
                    amP1 = false;
                    Platform.runLater(() -> {
                        lblTitle.setText("Player 2");
                        lblStatus.setText("Waiting for player 1 to move");
                    });
                }

                // Continue to play
                while (continueToPlay) {
                        waitForPlayerAction(); // Wait for player 1 to move
                        sendMove(); // Send the move to the server
                        receiveInfoFromServer(); // Receive info from the server
                }
                //display win totals
                Platform.runLater(() -> {
                    lblStatus.setText("Player 1 had: " + p1Wins + " wins. \nPlayer 2 had: " + p2Wins + " wins.");

                });

            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }).start();
    }

    /** Wait for the player to mark a cell */
    private void waitForPlayerAction() throws InterruptedException {
        while (waiting) {
            Thread.sleep(100);
        }

        waiting = true;
    }

    /** Send this player's move to the server */
    private void sendMove() throws IOException {
        toServer.writeInt(choice); // Send the selected row
         }

    /** Receive info from the server */
    private void receiveInfoFromServer() throws IOException {
        // Receive game status
        int status = fromServer.readInt();


        if (status == PLAYER1_WON) {
            // Player 1 won, stop playing
            continueToPlay = false;
            if (amP1 == true) {
                Platform.runLater(() -> lblStatus.setText("I won!"));
            }
            else {
                Platform.runLater(() ->
                        lblStatus.setText("Player 1 has won!"));
            }
            p1Wins++;
        }
        else if (status == PLAYER2_WON) {
            // Player 2 won, stop playing
            continueToPlay = false;
            if (amP1 == false) {
                Platform.runLater(() -> lblStatus.setText("I won!"));
            }
            else{
                Platform.runLater(() ->
                        lblStatus.setText("Player 2 has won!"));
            }
            p2Wins++;
        }
        else if (status == DRAW) {
            // No winner, game is over
            continueToPlay = false;
            Platform.runLater(() ->
                    lblStatus.setText("Game is over, no winner!"));

        }
        if(roundCount == 5){
            continueToPlay = false;
        }
        receiveMove();
    }

    private void receiveMove() throws IOException {
        // Get the other player's move
        int choice = fromServer.readInt();
            Platform.runLater(() -> {
                switch (choice){
                    case ROCK : lblStatus.setText("Opponent Played Rock");
                    case PAPER: lblStatus.setText("Opponent Played Paper");
                    case SCISSORS: lblStatus.setText("Opponent Played Scissors");
                }
            });
    }

    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
     */
    public static void main(String[] args) {
        launch(args);
    }
}