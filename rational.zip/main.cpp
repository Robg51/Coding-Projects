/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

class Rational{
private:
int numerator;
int denominator;
public:
Rational();
Rational(int num, int den);
Rational(int wholeNumber);
void setNum(int num);
void setDen(int den);
Rational operator *(Rational const &otherRational);
Rational operator +(Rational const &otherRational);
Rational operator /(Rational const &otherRational);
Rational operator -(Rational const &otherRational);
};

Rational :: Rational operator - (Rational const &otherRational){
    int gcd;
    for(int i = 1; i <= denominator && i <= otherRational.denominator){
        if(denominator % i == 0 && otherRational.denominator % i ==0){
            gcd = i;
        }
    }
    rational.denominator = (denominator * gcd) - (otherRational.denominator * gcd);
    rational.numerator = (numerator * gcd) - (otherRational.numerator * gcd);
}

Rational :: Rational operator + (Rational const &otherRational){
    int gcd;
    for(int i = 1; i <= denominator && i <= otherRational.denominator){
        if(denominator % i == 0 && otherRational.denominator % i ==0){
            gcd = i;
        }
    }
    rational.denominator = (denominator * gcd) + (otherRational.denominator * gcd);
    rational.numerator = (numerator * gcd) + (otherRational.numerator * gcd);
}

Rational :: Rational operator / (Rational const &otherRational){
    Rational rational;
    
    rational.numerator = numerator * otherRational.denominator;
    
    rational.denominator = denominator * otherRational.numerator;
    
    return rational;
}

Rational::Rational operator * (Rational const &otherRational) {

Rational rational; 

rational.numerator = numerator * otherRational.numerator;

rational.denominator = denominator * otherRational.denominator;

return rational;

}

Rational :: Rational(int num, int den){

numerator = num;
denominator = den; 
}

Rational :: Rational(){
numerator = 0;
denominator = 1;
}

Rational :: setNum(int num){
numerator = num;
}

Rational :: setDen(int den){
denominator = den;
}

Rational :: Rational(wholeNumber){

numerator = wholeNumber;
denominator = 1;
}


int main()
{
    int ans;
    int sum;
    int diff;
    int prod;
    int quot;
    Rational testRatNum(1,2);
    cout << "Please enter in a whole number 1-9: ";
    cin >> ans; 
    if(ans < 1; || ans > 9){
        cout<< "invalid number. program terminating."
        break;
    }
    else{
        Rational ratNum = new Rational(ans);
        cout << "testing addition: \n";
        sum = ratNum + testRatNum;
        cout<< sum ;
        cout << "\n testing subtraction:\n";
        diff = ratNum - testRatNum;
        cout<< diff;
        cout<<"\n testing multiplication: \n";
        prod = ratNum * testRatNum;
        cout << prod;
        cout << "\n testing division: \n";
        quot = ratNum / testRatNum;
        cout << quot;
        
    }
    cout << "program complete."; 
}