/*
Author: Dr.Gonzalez-Sanchez
This program is used to test my jave knowledge regarding
Classes, Objects, and Arrays.
 */
import java.util.Scanner;

public class AssignmentOneB {

    public static void main(String[] args) {

        TreasureMap treasureMap;
        Spot spotData;
        int row, col, rowNum, colNum;
        String input;
        Scanner sc = new Scanner(System.in);

        System.out.println("How many rows do you want?");
        rowNum = sc.nextInt();

        System.out.println("How many columns do you want?");
        colNum = sc.nextInt();

        treasureMap = new TreasureMap(rowNum, colNum);

        System.out.println("\nHiding Phase:\n\nEnter the position of the treasure.");

        System.out.println("Enter row number of the treasure:");
        row = sc.nextInt();

        System.out.println("Enter column number of the treasure:");
        col = sc.nextInt();

        while(treasureMap.isValid(row, col) == "No") {
            System.out.println("\nRow or column number is not valid. Enter a valid position.\n");

            System.out.println("Enter the position of the treasure.\nEnter row number of the treasure:");
            row = sc.nextInt();

            System.out.println("Enter column number of the treasure:");
            col = sc.nextInt();
        }

        treasureMap.setTreasureAt(row, col);

        System.out.println("\nFinding Phase:\n\nEnter anything to search or enter \"Q\" to quit.");
        input = sc.next();

        boolean foundTreasure = false;
        while(!input.equalsIgnoreCase("Q")&&!foundTreasure) {

            System.out.println("Enter row number of the spot to search:");
            row = sc.nextInt();

            System.out.println("Enter column number of the spot to search:");
            col = sc.nextInt();

            if(treasureMap.isValid(row, col) == "No") {
                System.out.println("\nRow or column number is not valid. Enter a valid position.\n");
            } else {
                if(treasureMap.searchSpot(row, col) == true) {
                    System.out.println("\nYou have found the treasure at row " + row + " and column " + col + "!");
                    System.out.println(treasureMap);
                    foundTreasure = true;
                } else {
                    System.out.println("\nThere is no treasure at row " + row + " and column " + col + ".");
                    System.out.println(treasureMap);
                }
            }

            if(!foundTreasure){
                System.out.println("\nEnter anything to search or enter \"Q\" to quit.");
                input = sc.next();
            }
        }

        sc.close();
    }
}