import static org.junit.jupiter.api.Assertions.*;

class CheckersLogicTest extends CheckersLogic{

    @org.junit.jupiter.api.Test
    void validMove() {
        assertAll(
                () -> assertTrue(validMove(24,35)),
                //() -> assertTrue(validMove(24,25)),
                () -> assertTrue(validMove(24,35))

        );
    }

    @org.junit.jupiter.api.Test
    void translatePos() {
        assertAll(
                () -> assertEquals(11, translatePos("a1")),
                // fail case () -> assertEquals(11, translatePos("a2")),
                () -> assertEquals(51, translatePos("e1"))

                );
    }

}