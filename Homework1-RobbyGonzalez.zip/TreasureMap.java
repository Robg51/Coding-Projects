/*
Author: Robby Gonzalez
This program acts as a placeholder for the Treasure Map that
will be used in AssignmentOneB.java. it is also going to be made
up of a double array of type Spot.
 */
public class TreasureMap {
    private Spot[][] spotGrid;

    /**
     * Defines the map and spotGrid with user
     * defined row and column values.
     */
    public TreasureMap(int rowNum, int columnNum){
        spotGrid = new Spot[rowNum][columnNum];
        for(int i = 0; i < rowNum; i++){
            for(int j = 0; j < columnNum; j++){
                spotGrid[i][j] = new Spot();
            }
        }
    }

    /**
     * This method will locate a valid user defined spot
     * on the map.
     * @param row
     * @param col
     */
    private Spot getSpotAt(int row, int col){
        return spotGrid[row][col];
    }

    /**
     * This method allows the user to place the
     * Treasure at whatever valid spot they choose.
     * @param row
     * @param col
     */
    public void setTreasureAt(int row, int col){
        Spot treasureSpot = new Spot();
        treasureSpot.hasTreasure = true;
        spotGrid[row][col] = treasureSpot;
    }

    /**
     * This method checks if the user defined spot given
     * located in spotGrid is valid.
     * @param row
     * @param col
     */
    public String isValid(int row, int col){
        if(row < 0 || col < 0 || row >= spotGrid[0].length || col >= spotGrid.length){
            return "No";
        }
        else{
            return "Yes";
        }
    }

    /**
     * This method first checks if the user given spot has been searched.
     * if it has, it will tell the user that it already has been searched.
     * otherwise, it will mark the user given spot as searched and return
     * the boolean value of hasTreasure for the given spot
     * @param col
     * @param row
     */
    public boolean searchSpot(int row, int col){
        if(spotGrid[row][col].isSearched){
            System.out.println("This spot has already been searched");
            return false;
        }
        else{
            spotGrid[row][col].isSearched = true;
            return spotGrid[row][col].hasTreasure;
        }
    }

    /**
     * A toString method to properly print the layout
     * of the Treasure map.
     */
    public String toString(){
        String header = "Map Layout:";
        header += System.lineSeparator();

        for(int i = 0; i < spotGrid[0].length; i++){
            String rowData = "";
            for(int j = 0; j < spotGrid.length; j++){
                rowData += spotGrid[i][j].toString() + " ";
            }
            header += rowData + System.lineSeparator();
        }
        return header;

    }
}
