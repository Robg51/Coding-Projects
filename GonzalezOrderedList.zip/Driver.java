package edu.ser222.m01_03;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Test area for list implementations.
 *
 * @author Robby Gonzalez, Acuna
 * @version (version)
 */
public class Driver {
    public static void main(String [] args) {
        //ListADT<Integer> list = new CompletedList<>(); //simpler version
        OrderedListADT<Integer> list = new CompletedOrderedList<>();

        //RA: These are _extremely_ simple tests! You will need to write more!
        boolean testPassed = false;
        try {
            list.removeFirst();
        }
        catch (NoSuchElementException e){
            e.printStackTrace();
            System.out.println("Success!");
            testPassed = true;
        }
        if(!testPassed){
            System.out.println("Test Failed.");
        }

        testPassed = false;
        try {
            list.removeLast();
        }
        catch (NoSuchElementException e){
            e.printStackTrace();
            System.out.println("Success!");
            testPassed = true;
        }
        if(!testPassed){
            System.out.println("Test Failed.");
        }


        testPassed = false;
        try {
            list.remove(2);
        }
        catch (NoSuchElementException e){
            e.printStackTrace();
            System.out.println("Success!");
            testPassed = true;
        }
        if(!testPassed){
            System.out.println("Test Failed.");
        }



        list.add(23);
        list.add(24);
        list.add(16);
        list.add(3);
        list.add(7);
        list.add(17);
        list.add(9);
        list.add(13);
        list.add(14);
        list.add(1);

        System.out.println(list);

        list.remove(7);
        list.removeFirst();
        list.remove(17);
        list.removeLast();
        list.remove(14);
        list.removeLast();

        System.out.println(list);

        /* Test Results:
            1 3 7 9 13 14 16 17 23 24
            3 9 13 16
        */
         Iterator<Integer> iterator = list.iterator();
         if(iterator.hasNext()){
             System.out.println("Iterator hasNext returned True successfully");
         }
         else{
             System.out.println("Expected to return true but did not.");
         }

        for (int i = 0; i < 6; i++) {
            System.out.print(iterator.next().toString() + " ");
        }
        System.out.println();
        if(iterator.hasNext()){
            System.out.println("Iterator hasNext returned True unexpectedly");
        }
        else{
            System.out.println("hasNext returned as False successfully.");
        }

        testPassed = false;
        try{
            iterator.next();
        }
        catch (NoSuchElementException e){
            e.printStackTrace();
            System.out.print("Success");
            testPassed = true;
        }

        if(!testPassed){
            System.out.println("Test Failed.");
        }
    }

}