import java.util.NoSuchElementException;
import java.util.HashMap;
import  java.util.LinkedList;
import java.util.Set;

public class BetterDiGraph implements EditableDiGraph {
    protected int Edge;
    protected int Vertex;
    private HashMap<Integer, LinkedList<Integer>> diGraph;

    //constructor for BetterDiGraph
    public BetterDiGraph(){
        this.Edge = 0;
        this.Vertex = 0;
        this.diGraph = new HashMap<>();
    }

    @Override
    public void addEdge(int v, int w) {
        if(!diGraph.containsKey(v)){        // if vertex v doesnt exist, add it
            addVertex(v);
        }
        if(!diGraph.containsKey(w)){        // if vertex w doesnt exist, add it
            addVertex(w);
        }
      /*  else if(diGraph.get(v).contains(w) == false){
            diGraph.get(v).push(w);
            Edge++;
        }*/
    }

    @Override
    public void addVertex(int v) {
        if(!diGraph.containsKey(v)){
            diGraph.put(v, new LinkedList<>());
            Vertex++;
        }
    }

    @Override
    public Iterable<Integer> getAdj(int v) {
        return diGraph.get(v);
    }

    @Override
    public int getEdgeCount() {
        return this.Edge;
    }

    @Override
    public int getIndegree(int v) throws NoSuchElementException {
        int temp = 0;
         if(!diGraph.containsKey(v)) {
             throw new NoSuchElementException();
         }
         for(Integer i : vertices()){
             if(i != v){
                 if(diGraph.get(i).contains(v)){
                     temp++;
                 }
             }
         }
        return temp;
    }

    @Override
    public int getVertexCount() {
        return this.Vertex;
    }

    @Override
    public void removeEdge(int v, int w) {
    if(!diGraph.containsKey(v)){
        return;
    }
    else{
        Edge--;
        diGraph.get(v).removeFirstOccurrence(w);
    }
    }

    @Override
    public void removeVertex(int v) {
        if (diGraph.containsKey(v)) {
            return;
        }
        for (Integer edge : diGraph.keySet()) {
            LinkedList<Integer> thisVertex = diGraph.get(edge);
            for (int i = thisVertex.size() - 1; i >= 0; i--) {
                int destEdge = thisVertex.get(i);
                if (destEdge == v) {
                    removeEdge(edge, destEdge);
                }
            }
        }
        Vertex = Vertex - (1 + diGraph.get(v).size());
        diGraph.remove(v);
    }

    @Override
    public Iterable<Integer> vertices() {
        Set<Integer> integers = diGraph.keySet();
        return integers;
    }

    @Override
    public boolean isEmpty() {
        return diGraph.isEmpty();
    }

    @Override
    public boolean containsVertex(int v) {
        return diGraph.containsKey(v);
    }
}
