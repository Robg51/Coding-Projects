#pragma once

#include <string>
#include <vector>

using namespace std;

class Student {
private:
    string name;
    int numClasses;
    vector<string> classList;

public:
    Student();
    Student(string n, int nc);
    void input();
    void output();
    void reset();

public:
    void setName(string n);
    string getName();
    void setNumClasses(int nc);
    int getNumClasses();
};