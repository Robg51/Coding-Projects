package edu.ser222.m01_03;



/**
 * CompletedOrderedList represents an implementation of an ordered list that builds on
 * CompletedList.
 *
 * @author (your name), Acuna
 * @version (version)
 */
public class CompletedOrderedList<T extends Comparable<T>> extends CompletedList<T>
        implements OrderedListADT<T> {

    //TODO: implement this!

    /**
     * Adds the specified element to this collection at the proper location
     *
     * @param element the element to be added to this collection
     * @throws NullPointerException if element is null
     */
    public void add(T element) {
        DoubleLinearNode<T> node = new DoubleLinearNode<T>(element);
        if (count != 0) {
            node.setPrev(tail);
            tail.setNext(node);
            tail = node;
            tail.setNext(null);
        } else {
            head = node;
            tail = node;
        }
        count++;
        modChange++;
    }
}
