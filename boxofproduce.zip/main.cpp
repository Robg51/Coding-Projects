/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <cstdlib>
#include <string>
#include<random>
#include<ctime>

using namespace std;

class BoxOfProduce{
private:
  string produce[5] = {"Broccoli", "Tomato", "Kiwi", "Kale", "Tomatillo"};
  string box[3];
public:
  BoxOfProduce();
  string getBox (int prodNum);
  void setBox (int repProd, int newProd);
  string getproduce (int prodNum);
  void outputBox();
};

int main(){
  BoxOfProduce box;
  bool loop = true;
  char ans;
  int repProd, newProd;
  string produce[5] = { "Broccoli", "Tomato", "Kiwi", "Kale", "Tomatillo"};

  while (loop){
    cout << "Here's what is in your box:\n";
    box.outputBox();
    cout << "Would you like to replace an item? 'y' for yes 'n' for no \n";
    cin >> ans;
    
    switch (ans){
	    case 'y':
	    case 'Y':
	        cout << "Enter the number listed next to the item you would like to replace in your box:\n ";
	        cin >> repProd;
	        cout << "Here is what is currently in stock:\n";
	        
	        for (int i = 0; i < 5; i++){
	        cout << i << " : " << produce[i] << endl;
	        }
	  
	        cout << "\nEnter the number listed next to the item you would like to add to your box: ";
	        cin >> newProd;
	        box.setBox (repProd, newProd);
	        break;
	    case 'N':
	    case 'n':
	        loop = false;
	        break;
	    default:
	        cout << "This is not a valid entry. Please try again.\n";
	    }
    }
  cout << "Your box:\n";
  box.outputBox();
  return 0;
}

BoxOfProduce::BoxOfProduce()
{
    srand(time(NULL));
        for (int i = 0; i < 3; i++){
            box[i] = produce[rand() % 5];
        }
}

string BoxOfProduce::getBox (int prodNum){
    return box[prodNum];
}

void BoxOfProduce::setBox (int prevProduce, int newProduce){
  box[prevProduce] = produce[newProduce];
}

string BoxOfProduce::getproduce (int prodNum){
    return produce[prodNum];
}

void BoxOfProduce::outputBox(){
    for (int i = 0; i < 3; i++){
      cout << i << " : " << box[i] << endl;
    }
}
