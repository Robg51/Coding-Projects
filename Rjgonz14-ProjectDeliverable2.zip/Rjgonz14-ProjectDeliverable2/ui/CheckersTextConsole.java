import java.util.*;

public class CheckersTextConsole {
    protected final static int SIZE = 8;
    protected char[][] board;
    protected int Xcheckers;
    protected int Ocheckers;
    protected char playerMove;

    /**
     * Constructor that creates and sets the
     * layout of the array that is going to be
     * used for the checkerboard.
     */
    public CheckersTextConsole() {

        board = new char[SIZE][SIZE];
        Xcheckers = 12;
        Ocheckers = 12;
        playerMove = 'x';

        // Initialize board with all the red and black checkers in starting
        // positions.
        int i, j;
        for (i = 0; i < SIZE; i++)
            for (j = 0; j < SIZE; j++)
                board[i][j] = '_';

        for (i = 1; i < SIZE; i += 2) {
            board[i][1] = 'x';
            board[i][5] = 'o';
            board[i][7] = 'o';
        }
        for (i = 0; i < SIZE; i += 2) {
            board[i][0] = 'x';
            board[i][2] = 'x';
            board[i][6] = 'o';
        }
    }

    /**
     * Prints the checkerboard
     */
    public void printBoard() {
        int i, j;
        for (i = 0; i < SIZE; i++) {
            System.out.print((i + 1) + " ");
            for (j = 0; j < SIZE; j++) {
                System.out.print(board[j][i] + " ");
            }
            System.out.println();
        }
        System.out.println("  a b c d e f g h ");
    }
}
