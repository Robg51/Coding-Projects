package com.example.rockpaperscissors.RPSServer;

public class RPSConstants {
    public final static int PLAYER1 = 1; // Indicate player 1
    public final static int PLAYER1_WON = 1; // Indicate player 1 won
    public final static int PLAYER2 = 2; // Indicate player 2
    public final static int PLAYER2_WON = 2; // Indicate player 2 won
    public final static int DRAW = 3; // Indicate a draw
    public final static int CONTINUE = 4; // Indicate to continue

    public final static int ROCK = 0;
    public final static int PAPER = 1;
    public final static int SCISSORS = 2;
}
