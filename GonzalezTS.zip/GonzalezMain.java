import java.io.*;
import java.util.HashMap;

/**
 * Program for generating kanji component dependency order via topological sort.
 *
 * @author (your name), Acuna
 * @version (version)
 */
public class GonzalezMain {

    /**
     * Entry point for testing.
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        //TODO: implement this 

        //Freebie: this is one way to load the UTF8 formated character data.
        BufferedReader indexReader = new BufferedReader(new InputStreamReader(new FileInputStream(new File("data-kanji.txt")), "UTF8"));
        String ID = indexReader.readLine();
        HashMap<Integer, String> hMap = new HashMap<>();
        BetterDiGraph diGraph = new BetterDiGraph();

        while((ID = indexReader.readLine()) != null){
            String[] array = ID.split("\t");

            if(!array[0].startsWith("#")){
                Integer i = Integer.parseInt(array[0]);
                String j = array[1];
                hMap.put(i,j);
            }
        }

        BufferedReader indexReader2 = new BufferedReader(new InputStreamReader(new FileInputStream(new File("data-components.txt")), "UTF8"));
        String component = indexReader2.readLine();

        while((component = indexReader2.readLine()) != null){
            String[] array = component.split("\t");
            if(!array[0].startsWith("#")){
                diGraph.addEdge(Integer.parseInt(array[0]), Integer.parseInt(array[1]));
            }
        }
        IntuitiveTopological IT = new IntuitiveTopological(diGraph);
        IT.order();

    }
}